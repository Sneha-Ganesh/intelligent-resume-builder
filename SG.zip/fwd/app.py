from flask import Flask,request,render_template,Response
import matplotlib.pyplot as plt
import io
import base64
from matplotlib.offsetbox import TextArea, DrawingArea, OffsetImage, AnnotationBbox
import matplotlib.image as mpimg


app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/home")
def home():
    return render_template("home.html")

#@app.route('/form_home',methods=['POST','GET'])
#def result():
#    name_1 = request.form['Name']
#    add_1 = request.form['Address']
#    job_1 = request.form['Job']
#    con_1 = request.form['Contact']
#    return render_template('result.html',Name=name_1,Address=add_1,Job=job_1,Contact=con_1)

@app.route('/form_home',methods=['POST','GET'])
def download_figure():
    name_1 = request.form['Name']
    add_1 = request.form['Address']
    job_1 = request.form['Job']
    con_1 = request.form['Email']
    con_2 = request.form['linkedin']
    con_3 = request.form['Number']
    ed1_t = request.form['10inst']
    ed1_c = request.form['10cgpa']
    ed2_t = request.form['12inst']
    ed2_c = request.form['12cgpa']
    comp1_t = request.form['comp1']
    comp1_d = request.form['comp1d']
    Name =  name_1
    Title = job_1
    Contact = 'Atlanta, GA\n404-XXX-XXXX\nwekrklndATgmailDOTcom\nlinkedin.com/in/ekirkland\ngithub.com/e-kirkland'
    ProjectsHeader = 'PROJECTS/PUBLICATIONS'
    ProjectOneTitle = 'Increasing Kaggle Revenue'
    ProjectOneDesc = '- Published by Towards Data Science\n- Analyzed user survey to recommend most profitable future revenue source\n- Cleaned/visualized data using pandas/matplotlib libraries in Python'
    ProjectTwoTitle = 'NYC School Data Cleaning & Analysis'
    ProjectTwoDesc = '- Cleaned and combined several tables using pandas library in Python\n- Used PDE and visualization to determine correlations for future study'
    ProjectThreeTitle = 'Pandas Cleaning and Visualization'
    ProjectThreeDesc = '- Cleaned data for analysis using pandas library in Python\n- Used pandas and matplotlib to explore which cars hold the most value'
    Portfolio = 'Portfolio: rebrand.ly/ekirkland'
    WorkHeader = 'WORK EXPERIENCE'
    WorkOneTitle = comp1_t
    WorkOneTime = comp1_d
    WorkOneDesc = '- Raised $350k in startup funds, recruited/organized launch team\n- Coordinated branding and communication strategy\n- Led team of 80 volunteer and staff leaders'
    WorkTwoTitle = 'Second Company / Second Position'
    WorkTwoTime = '2/2007-8/2013'
    WorkTwoDesc = '- Led team of over 100 full-time and contract staff\n- Helped create branding and messaging for weekly content\n- Created/directed musical elements at weekly events for up to 10,000 people'
    WorkThreeTitle = 'Third Company / Third Position'
    WorkThreeTime = '6/2004-2/2007'
    WorkThreeDesc = '- Planned/Coordianted Toronto arena event and South Africa speaking tour\n- Oversaw research for published products'
    EduHeader = 'EDUCATION'
    EduOneTitle = ed1_t
    #EduOneTime = ed1_c
    EduOneCGPA = 'CGPA/Overall Percentage: ',ed1_c,' %'
    EduTwoTitle = ed2_t
    #EduTwoTime = float(input("Education CGPA/ Overall Percentage: "))
    EduTwoCGPA = 'CGPA/Overall Percentage: ',ed2_c,' %'
    SkillsHeader = 'Skills'
    SkillsDesc = '- Python\n- Pandas\n- NumPy\n- Data Visualization\n- Data Cleaning\n- Command Line\n- Git and Version Control\n- SQL\n- APIs\n- Probability/Statistics\n- Data Manipulation\n- Excel'
    ExtrasTitle = 'DataQuest\nData Scientist Path'
    ExtrasDesc = 'Learned popular data science\nlanguages, data cleaning and\nmanipulation, machine learning \nand statistical analysis'
    CodeTitle = 'View Portfolio'

    #import matplotlib.pyplot as plt
# Setting style for bar graphs
# set font
    plt.rcParams['font.family'] = 'sans-serif'
    plt.rcParams['font.sans-serif'] = 'STIXGeneral'
    fig, ax = plt.subplots(figsize=(9, 12.25))
# Decorative Lines
    ax.axvline(x=.6, ymin=0, ymax=1, color='#007ACC', alpha=0.0, linewidth=200)
    plt.axvline(x=.99, color='#000000', alpha=0.5, linewidth=365)
    plt.axhline(y=.88, xmin=0, xmax=1, color='#ffffff', linewidth=3)
# set background color
    ax.set_facecolor('white')
# remove axes
    plt.axis('off')
# add text
    #plt.annotate(Header, (.02,.98), weight='regular', fontsize=8, alpha=.75)
    plt.annotate(Name, (.02,.94), weight='bold', fontsize=20)

    plt.annotate(Title, (.02,.91), weight='regular', fontsize=14)
    plt.annotate(add_1, (.640,.906), weight='regular', fontsize=8, color='#ffffff')
    plt.annotate(con_1, (.640,.920), weight='regular', fontsize=8, color='#ffffff')
    plt.annotate(con_2, (.640,.935), weight='regular', fontsize=8, color='#ffffff')
    plt.annotate(con_3, (.640,.948), weight='regular', fontsize=8, color='#ffffff')
    plt.annotate(ProjectsHeader, (.02,.86), weight='bold', fontsize=10, color='#58C1B2')
    plt.annotate(ProjectOneTitle, (.02,.832), weight='bold', fontsize=10)
    plt.annotate(ProjectOneDesc, (.04,.78), weight='regular', fontsize=9)
    plt.annotate(ProjectTwoTitle, (.02,.745), weight='bold', fontsize=10)
    plt.annotate(ProjectTwoDesc, (.04,.71), weight='regular', fontsize=9)
    plt.annotate(ProjectThreeTitle, (.02,.672), weight='bold', fontsize=10)
    plt.annotate(ProjectThreeDesc, (.04,.638), weight='regular', fontsize=9)
    plt.annotate(Portfolio, (.02,.6), weight='bold', fontsize=10)
    plt.annotate(WorkHeader, (.02,.54), weight='bold', fontsize=10, color='#58C1B2')
    plt.annotate(WorkOneTitle, (.02,.508), weight='bold', fontsize=10)
    plt.annotate(WorkOneTime, (.02,.493), weight='regular', fontsize=9, alpha=.6)
    plt.annotate(WorkOneDesc, (.04,.445), weight='regular', fontsize=9)
    plt.annotate(WorkTwoTitle, (.02,.4), weight='bold', fontsize=10)
    plt.annotate(WorkTwoTime, (.02,.385), weight='regular', fontsize=9, alpha=.6)
    plt.annotate(WorkTwoDesc, (.04,.337), weight='regular', fontsize=9)
    plt.annotate(WorkThreeTitle, (.02,.295), weight='bold', fontsize=10)
    plt.annotate(WorkThreeTime, (.02,.28), weight='regular', fontsize=9, alpha=.6)
    plt.annotate(WorkThreeDesc, (.04,.247), weight='regular', fontsize=9)
    plt.annotate(EduHeader, (.02,.220), weight='bold', fontsize=10, color='#58C1B2')
    plt.annotate(EduOneTitle, (.02,.190), weight='bold', fontsize=10)
    plt.annotate(EduOneCGPA, (.02,.170), weight='bold', fontsize=10)
    plt.annotate(EduTwoTitle, (.02,.140), weight='bold', fontsize=10)
    plt.annotate(EduTwoCGPA, (.02,.120), weight='bold', fontsize=10)
    plt.annotate(SkillsHeader, (.640,.8), weight='bold', fontsize=10, color='#ffffff')
    plt.annotate(SkillsDesc, (.640,.56), weight='regular', fontsize=10, color='#ffffff')
    plt.annotate(ExtrasTitle, (.640,.43), weight='bold', fontsize=10, color='#ffffff')
    plt.annotate(ExtrasDesc, (.640,.345), weight='regular', fontsize=10, color='#ffffff')
    plt.annotate(CodeTitle, (.640,.2), weight='bold', fontsize=10, color='#ffffff')


# Save the graph to a buffer
    buffer = io.BytesIO()
    plt.savefig(buffer, dpi=300, bbox_inches='tight',format='pdf')
    buffer.seek(0)

    # Set the buffer as the response data and specify the filename
    response = Response(buffer, mimetype='application/pdf')
    response.headers.set('Content-Disposition', 'attachment', filename='my_resume.pdf')
    return response

'''
def graph():
# Text Variables
#Header = input("Enter a header: \n ")
    name_1 = request.form['Name']
    add_1 = request.form['Address']
    job_1 = request.form['Job']
    con_1 = request.form['Contact']
    Name =  name_1
    Title = job_1
    Contact = 'Atlanta, GA\n404-XXX-XXXX\nwekrklndATgmailDOTcom\nlinkedin.com/in/ekirkland\ngithub.com/e-kirkland'
    ProjectsHeader = 'PROJECTS/PUBLICATIONS'
    ProjectOneTitle = 'Increasing Kaggle Revenue'
    ProjectOneDesc = '- Published by Towards Data Science\n- Analyzed user survey to recommend most profitable future revenue source\n- Cleaned/visualized data using pandas/matplotlib libraries in Python'
    ProjectTwoTitle = 'NYC School Data Cleaning & Analysis'
    ProjectTwoDesc = '- Cleaned and combined several tables using pandas library in Python\n- Used PDE and visualization to determine correlations for future study'
    ProjectThreeTitle = 'Pandas Cleaning and Visualization'
    ProjectThreeDesc = '- Cleaned data for analysis using pandas library in Python\n- Used pandas and matplotlib to explore which cars hold the most value over time'
    Portfolio = 'Portfolio: rebrand.ly/ekirkland'
    WorkHeader = 'EXPERIENCE'
    WorkOneTitle = 'Example Company / Example Position'
    WorkOneTime = '8/2013-Present'
    WorkOneDesc = '- Raised $350k in startup funds, recruited/organized launch team\n- Coordinated branding and communication strategy\n- Led team of 80 volunteer and staff leaders'
    WorkTwoTitle = 'Second Company / Second Position'
    WorkTwoTime = '2/2007-8/2013'
    WorkTwoDesc = '- Led team of over 100 full-time and contract staff\n- Helped create branding and messaging for weekly content\n- Created/directed musical elements at weekly events for up to 10,000 people'
    WorkThreeTitle = 'Third Company / Third Position'
    WorkThreeTime = '6/2004-2/2007'
    WorkThreeDesc = '- Planned/Coordianted Toronto arena event and South Africa speaking tour\n- Oversaw research for published products'
    EduHeader = 'EDUCATION'
    EduOneTitle = 'Example University, Bachelor of Business Administration'
    EduOneTime = '2000-2004'
    EduOneDesc = '- Major: Management, Minor: Statistics'
    EduTwoTitle = 'Example University, Master of Arts'
    EduTwoTime = '2013-2017'
    SkillsHeader = 'Skills'
    SkillsDesc = '- Python\n- Pandas\n- NumPy\n- Data Visualization\n- Data Cleaning\n- Command Line\n- Git and Version Control\n- SQL\n- APIs\n- Probability/Statistics\n- Data Manipulation\n- Excel'
    ExtrasTitle = 'DataQuest\nData Scientist Path'
    ExtrasDesc = 'Learned popular data science\nlanguages, data cleaning and\nmanipulation, machine learning \nand statistical analysis'
    CodeTitle = 'View Portfolio'
# Setting style for bar graphs
# set font
    plt.rcParams['font.family'] = 'sans-serif'
    plt.rcParams['font.sans-serif'] = 'STIXGeneral'
    fig, ax = plt.subplots(figsize=(8.5, 11))
# Decorative Lines
    ax.axvline(x=.5, ymin=0, ymax=1, color='#007ACC', alpha=0.0, linewidth=50)
    plt.axvline(x=.99, color='#000000', alpha=0.5, linewidth=300)
    plt.axhline(y=.88, xmin=0, xmax=1, color='#ffffff', linewidth=3)
# set background color
    ax.set_facecolor('white')
# remove axes
    plt.axis('off')
# add text
    #plt.annotate(Header, (.02,.98), weight='regular', fontsize=8, alpha=.75)
    plt.annotate(Name, (.02,.94), weight='bold', fontsize=20)
    plt.annotate(Title, (.02,.91), weight='regular', fontsize=14)
    plt.annotate(Contact, (.7,.906), weight='regular', fontsize=8, color='#ffffff')
    plt.annotate(ProjectsHeader, (.02,.86), weight='bold', fontsize=10, color='#58C1B2')
    plt.annotate(ProjectOneTitle, (.02,.832), weight='bold', fontsize=10)
    plt.annotate(ProjectOneDesc, (.04,.78), weight='regular', fontsize=9)
    plt.annotate(ProjectTwoTitle, (.02,.745), weight='bold', fontsize=10)
    plt.annotate(ProjectTwoDesc, (.04,.71), weight='regular', fontsize=9)
    plt.annotate(ProjectThreeTitle, (.02,.672), weight='bold', fontsize=10)
    plt.annotate(ProjectThreeDesc, (.04,.638), weight='regular', fontsize=9)
    plt.annotate(Portfolio, (.02,.6), weight='bold', fontsize=10)
    plt.annotate(WorkHeader, (.02,.54), weight='bold', fontsize=10, color='#58C1B2')
    plt.annotate(WorkOneTitle, (.02,.508), weight='bold', fontsize=10)
    plt.annotate(WorkOneTime, (.02,.493), weight='regular', fontsize=9, alpha=.6)
    plt.annotate(WorkOneDesc, (.04,.445), weight='regular', fontsize=9)
    plt.annotate(WorkTwoTitle, (.02,.4), weight='bold', fontsize=10)
    plt.annotate(WorkTwoTime, (.02,.385), weight='regular', fontsize=9, alpha=.6)
    plt.annotate(WorkTwoDesc, (.04,.337), weight='regular', fontsize=9)
    plt.annotate(WorkThreeTitle, (.02,.295), weight='bold', fontsize=10)
    plt.annotate(WorkThreeTime, (.02,.28), weight='regular', fontsize=9, alpha=.6)
    plt.annotate(WorkThreeDesc, (.04,.247), weight='regular', fontsize=9)
    plt.annotate(EduHeader, (.02,.185), weight='bold', fontsize=10, color='#58C1B2')
    plt.annotate(EduOneTitle, (.02,.155), weight='bold', fontsize=10)
    plt.annotate(EduOneTime, (.02,.14), weight='regular', fontsize=9, alpha=.6)
    plt.annotate(EduOneDesc, (.04,.125), weight='regular', fontsize=9)
    plt.annotate(EduTwoTitle, (.02,.08), weight='bold', fontsize=10)
    plt.annotate(EduTwoTime, (.02,.065), weight='regular', fontsize=9, alpha=.6)
    plt.annotate(SkillsHeader, (.7,.8), weight='bold', fontsize=10, color='#ffffff')
    plt.annotate(SkillsDesc, (.7,.56), weight='regular', fontsize=10, color='#ffffff')
    plt.annotate(ExtrasTitle, (.7,.43), weight='bold', fontsize=10, color='#ffffff')
    plt.annotate(ExtrasDesc, (.7,.345), weight='regular', fontsize=10, color='#ffffff')
    plt.annotate(CodeTitle, (.7,.2), weight='bold', fontsize=10, color='#ffffff')

# Save the graph to a buffer
    buffer = io.BytesIO()
    plt.savefig(buffer, dpi=300, bbox_inches='tight',format='png')
    buffer.seek(0)

    # Encode the buffer as a base64 string and render it in an HTML template
    #image_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    return Response(buffer,mimetype='image/png')
'''


#@app.route('/download_figure')

if __name__ == "__main__":
    app.run()